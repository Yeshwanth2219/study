import React from 'react';
import logo from './logo.svg';
import './App.css';
import {MultiColorProgressBar} from "./MultiColorProgressBar";


export class App extends React.Component {

  constructor(props) {
    super(props);
    this.state={
      update: 1
    }
  }
  updateValue(e) {
    e.preventDefault();
    this.setState({
      updateValue: this.state.update+1
    })
  }
  render() {
  
let patchTaskValue = {
    value: 20,
    type: "pre-task",
    operation: "add"
}
  return (
    <div className="App">
      <a href="#" onClick={this.updateValue.bind(this)}>Update</a>
      <MultiColorProgressBar readings={patchTaskValue} patchStartTime={new Date()} endTime={60} updateValue={this.state.updateValue}/>
    </div>
  );
}
}

export default App;
