import React from "react";
import "./Multicolor.css";
import moment from "moment";

export class MultiColorProgressBar extends React.Component {
    constructor(props) {
      super(props);   
      this.state = {
          progressBarDetails: [
            {
                name: 'pre-task',
                value: 0,
                color: '#eb4d4b',
                time: ""
            },
            {
                name: 'patch-task',
                value: 100,
                color: '#6ab04c',
                time: ""
            },
            {
                name: 'post-task',
                value: 0,
                color: 'orange',
                time: ""
            }
          ],
          progressBar: false
      } 
    }
   
    getTaskPortion(progressValue) {        
        const {readings, patchStartTime, endTime} = progressValue;
        const modifiedTime = moment(patchStartTime).format("hh:mm A");
        const patchEndTime = moment(patchStartTime).add(endTime, "minutes").format("hh:mm A")
        let updatedProgress = this.state.progressBarDetails.map((progressitems, index) => {
            if(progressitems.name === "patch-task") {
                if(readings.type === "pre-task" && readings.operation === "add") {
                    progressitems.value = progressitems.value - readings.value;
                    let preTaskStartTime = moment(patchStartTime).subtract(readings.vale);
                    let preTaskEndTime = modifiedTime; 
                    progressitems.time = `${preTaskStartTime}-${preTaskEndTime}`; 

                } else if(readings.type === "pre-task" && readings.operation === "subtract") {
                    progressitems.value = progressitems.value + readings.value;
                } else if(readings.type === "post-task" && readings.operation === "add") {
                    progressitems.value = progressitems.value - readings.value;
                    progressitems.time = `${moment(patchStartTime).subtract(readings.vale)}-${patchEndTime}`; 

                } else if(readings.type === "post-task" && readings.operation === "subtract") {
                    progressitems.value = progressitems.value + readings.value;
                } else {
                    progressitems.time = `${modifiedTime}-${patchEndTime}`;                
                }


                // if((readings.type === "pre-task" || readings.type === "post-task")  && readings.operation === "add" ) {
                //     progressitems.value = progressitems.value - readings.value;
                //     progressitems.time = `${moment(patchStartTime).subtract(readings.vale)}-${patchEndTime}`; 
                // } else {
                //     progressitems.value = progressitems.value + readings.value;
                // }
                progressitems.time = `${modifiedTime}-${patchEndTime}`;                
            } else if ((progressitems.name === "pre-task" && readings.type === "pre-task") || (progressitems.name === "post-task" && readings.type === "post-task"))  {              
                if(readings.operation === "add") {
                    progressitems.value = progressitems.value + readings.value;
                    progressitems.time =  `${modifiedTime}- ${moment(patchStartTime).add(readings.value, "minutes").format("hh:mm A")}`;   
                } else {
                    progressitems.value = progressitems.value >= readings.value ? progressitems.value - readings.value : 0
                }               
            } 
            return progressitems;             
        });
        if(!this.state.progressBar) {
            this.setState({
                progressBar: true
            })
        }
        return updatedProgress;
    }

    patchWindowTimeFrame = (patchStartTime, mins=30) => {
        
    }

    componentDidUpdate(prevProps, prevState) {
        const progressData = this.getTaskPortion(this.props);
        // console.log(progressData);
        // return {
        //     progressBarDetails: [
        //         progressData
        //     ]
        // }
        if(this.state.showBar) {
            this.setState({
            progressBarDetails: progressData,
            progressBar: true
            })
        }
    }

    /**
     * Method to render the progress bar 
     */
    renderProgressBar() {
        console.log("test", this.state.progressBarDetails);
        const progressBar = this.state.progressBarDetails || [];
        let bars = progressBar.length && progressBar.map((item, i) => {
           // debugger;
            if(item.value > 0) {
                return (
                    <div className="bar" style={{'backgroundColor': item.color, 'width': item.value + '%'}}  key={i}>
                        <span>{item.time}</span>
                    </div>
                )
            }
        });
        return bars;
    }

    render() {  	  
      return (
        <div className="multicolor-bar">
            <div className="bars">
                {this.renderProgressBar()}
            </div>
        </div>
      );
    }
  }
  
